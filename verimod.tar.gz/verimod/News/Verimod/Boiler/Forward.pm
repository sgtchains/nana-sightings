package News::Verimod::Boiler::Forward;

use strict;

1;

__DATA__
X-Forwarded-By: $modbot
@HEADERS

@BODY
