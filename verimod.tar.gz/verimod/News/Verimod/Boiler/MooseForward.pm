package News::Verimod::Boiler::Forward;

use strict;

1;

__DATA__
To: $poster-noconfirm
From: $modbot
Reply-to: $contact
Subject: [$shortname] $message-id - post forwarded 

Your article has been approved for the group $newsgroup, and has 
been forwarded along to $forward-to for further processing.  

If you do not wish to receive these notices in the future, include the
line "X-No-Confirm: yes" in the headers or the first line of your posts.  
It may also be possible to turn off these confirmations permanently,
consult the newsgroup's FAQ for details.

			- $modbot
@SIGNATURE
