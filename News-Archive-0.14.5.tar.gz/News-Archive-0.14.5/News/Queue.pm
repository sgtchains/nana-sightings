package News::Queue;
our $VERSION = "0.01";

# -*- Perl -*-		Wed 07 Mar 14:28:42 CST 2007 
###############################################################################
# Written by Tim Skirvin <tskirvin@killfile.org>.  Copyright 2007,
# Tim Skirvin.  Redistribution terms are below.
###############################################################################

=head1 NAME

News::Queue - keep track of newsgroup information

=head1 SYNOPSIS

  use News::Queue;
  my $groupinfo= News::Active->new( '/home/tskirvin/kiboze/newsgroups' );
  $groupinfo->subscribe("humanities.philosophy.objectivism");
  $groupinfo->write;

See below for more information.

=head1 DESCRIPTION

News::Queue is used to keep track of passive newsgroup information in
an external file.  It contains many C<News::Queue::Entry> objects, one
for each newsgroup we are subscribed to.  It should be a fairly simple
module to use and understand, as it is only a subsection of
C<News::Archive>.

=head1 USAGE

=head2 Variables

=over 4

=item $News::Queue::DEBUG - default value for c<debug()> in new objects.

=item $News::Active::READONLY - default value for C<readonly()> in new objects.


=back

=cut

###############################################################################
### main() ####################################################################
###############################################################################

use strict;
use News::Queue::Entry;
use News::Lock;
use Fcntl qw(:DEFAULT :flock);
use vars qw( $DEBUG $READONLY @ISA );

$DEBUG    = 0;
$READONLY = 1;

@ISA = qw( News::Lock );

=head2 Basic Functions 

The following functions give us access to the object class

=over 4

=item new ( FILE )

Creates and returns a new News::Queue object.  C<FILE> is the filename
(later accessed with C<filename()>) that we will load old information from
and save to when we close the object.  It will be created if it doesn't
already exist, and read (with C<read()>) from if it does.

If C<HASH> is offered, its possible values:
  
  debug                 Print debugging information when using this 
                        object.  Defaults to $DEBUG.
  readonly              Don't write anything back out with this object
                        when we're done with it.  Defaults to $READONLY.

Returns undef on failure, or the object on success.

=cut

sub new {
  my ($proto, $file, %hash) = @_;
  return undef unless $file;
  my $class = ref($proto) || $proto;
  my $self = {
	entries  => 	{ },
  	filename =>     $file,
        debug    =>     $hash{'debug'}    || $DEBUG    || 0,
        readonly =>     defined $hash{'readonly'} ? $hash{'readonly'} 
                                                  : $READONLY || 0,
        lockfile =>     $file,
  	     };
  bless $self, $class;
  $self->read($file);
  $self;
}

=item reload ( )

=cut

sub reload { my ($self) = @_; $self->read( $self->filename ); $self }

=item entries ()

Returns a hash reference containing all enclosed entries; the keys
are the message-IDs, and the values are B<News::Queue::Entry> objects.  

=item filename ()

Returns the filename used for loading and saving our News::Queue
information.  

=item debug ()

Returns true if we want to print debugging information, false otherwise.  

=item readonly ()

Returns true if we shouldn't write out the information later, false
otherwise.  

=cut

sub entries  { shift->{entries}  || {} }
sub filename { shift->{filename} || undef }
sub debug    { shift->{debug}    || 0 }
sub readonly { shift->{readonly} || 0 }

=item entry ( GROUP )

Returns the News::Queue::Entry object for C<GROUP>, or undef if none
exists.

=cut

sub entry    { my ($self, $entry) = @_; $self->entries->{$entry} || undef }

=item entries_by_status ( STATUS )

Returns an array of News::Queue::Entry objects whose status matches C<STATUS>.

=cut

sub entries_by_status { 
  my ($self, $status) = @_;
  my @return;
  foreach (sort keys %{$self->entries}) { 
    next unless $status == $_->status;
    push @return, $self->entry($_); 
  }
  @return;
}

=back

=head2 Newsgroup Functions 

The following functions implement the functions that we actually want to
use this module for, ie adding groups and articles to the active file.

=over 4

=item update_queue ( ID, STATUS )

Adds a News::Queue::Entry entry for the given C<ID> with status C<STATUS>; or,
if an entry already exists, updates that entry.

Returns the relevant status information on success, undef otherwise.

=cut

sub update_queue { 
  my ($self, $id, $status) = @_;
  return undef unless $id;
  return undef unless $status;
  my $entry;
  if ($entry = $self->entries->{$id}) { 
    $entry->status($status) unless ($entry->status eq $status);
  } else { 
    $self->entries->{$id} = new News::Queue::Entry(join("::", $id, $status));
  }
  
  # foreach (keys %{$self->entries}) { warn $self->entries->{$_}->output, "\n" }
  $self->entries->{$id};
}

sub vote {
  my ($self, $id, $user, $vote) = @_;
}

=item remove_queue ( ID )

=cut

sub remove_queue { 
  my ($self, $id) = @_;
  return undef unless $id;
  if (my $entry = $self->entries->{$id}) { 
    delete $self->entries->{$id}; 
    return $entry;
  } else { return undef }
}

=item inqueue ( GROUP )

Returns 1 if this message is in the queue, 0 otherwise.

=cut

sub inqueue { 
  my ($self, $entry) = @_;
  return 0 unless $entry;
  $self->entries->{$entry} ? 1 : 0; 
}

=back

=head2 Input/Output Functions 

The following functions are used for reading, displaying, and saving
information from News::Queue and News::Queue::Entry.

=over 4

=item read ( [FILE] )

Reads News::Queue::Entry information from C<FILE> (or the value of
C<file()>), populating the News::Queue object.  This file contains
lines that each contain the output from a single
C<News::Queue::Entry::output()> call.  Returns 1 on success, undef
otherwise.

=cut

sub read {
  my ($self, $file) = @_;
  $file ||= $self->filename;  
  return undef unless $file;
  $$self{entries} = {};
  print "Reading from $file\n" if $self->debug;
  ( $self->readonly ? $self->readlock : $self->lock ) 
                        or ( warn "Couldn't get lock" && return undef);
  open(FILE, $file) or (warn "Couldn't read from $file: $!\n" && return undef);
  foreach (<FILE>) { 
    chomp;
    s/#.*$//;	# Trim comments
    s/^\s+//;  	# ...and leading whitespace
    next unless $_;
    my $entry = new News::Queue::Entry($_) or next;
    $self->entries->{$entry->id} = $entry;
  }  
  close FILE;  
  1;
}

=item printable ()

Returns an array (or arrayref, depending on invocation) containing the
value of C<News::Queue::Entry::print()> on each entry within the
News::Queue object.  These are then suitable for printing.

=cut

sub printable { 
  my ($self) = @_;
  my @return;
  foreach (sort keys %{$self->entries}) { 
    my $info = $self->entry($_)->print;
    push @return, $info;
  }
  wantarray ? @return : join("\n", @return); 
}

sub prettyprint {
  
}
=item output ()

Returns an array (or arrayref, depending on invocation) containing the
value of C<News::Queue::Entry::output()> on each entry within the
News::Queue object.  These are then suitable for saving to a database
and later reloading.

=cut

sub output {
  my ($self) = @_;
  my @return;
  foreach (sort keys %{$self->entries}) { 
    push @return, $self->entry($_)->output;
  }
  wantarray ? @return : join("\n", @return); 
}

=item write ( [FILE] )

Using the information from output(), writes out to C<FILE> (or the value
of C<file()>).  Returns 1 on success, undef otherwise.  If the readonly
flag is set, we don't actually write anything back out.

Note that this function is called when the object is destroyed as well.

=cut

sub write {
  my ($self, $file) = @_;
  $file ||= $self->filename;  
  if ( $self->readonly || ! $self->locked ) {
    warn "Not writing output, readonly!\n" if $self->debug;
    return 1; 
  } 
  return undef unless $file;
  print "Writing to $file\n" if $self->debug;

  open(FILE, ">$file") 
	or (warn "Couldn't write to $file: $!\n" && return undef);
  print FILE join("\n", $self->output);
  close FILE;
  $self->unlock();

  $self->read($self->filename);

  1;
}

###############################################################################
### Locking Subroutines #######################################################
###############################################################################

sub lockfile { $_[0]->{lockfile} }
sub locked { $_[0]->{lock} ? 1 : 0 }         

###############################################################################
### Internal Functions ########################################################
###############################################################################

### DESTROY
# Item destructor.  Make sure the file is written back out.
sub DESTROY { shift->write }

1;

=head1 NOTES

=head1 TODO

Write something that actually uses the voting code.

=head1 REQUIREMENTS

=head1 SEE ALSO

B<News::Queue::Entry>

=head1 AUTHOR

Tim Skirvin <tskirvin@killfile.org>

=head1 HOMEPAGE

B<http://www.killfile.org/~tskirvin/software/news-archive/>

=head1 LICENSE

This code may be redistributed under the same terms as Perl itself.

=head1 COPYRIGHT

Copyright 2007, Tim Skirvin.

=cut

###############################################################################
### Version History ###########################################################
###############################################################################
# 0.01          Wed 07 Mar 14:56:19 CST 2007    tskirvin
### Initial version; documentation isn't finished by any means.
