$VERSION = "0.90";
package News::Lock;
our $VERSION = "0.90";

# -*- Perl -*-		Sun 11 Mar 12:03:15 CST 2007 
###############################################################################
# Written by Tim Skirvin <tskirvin@killfile.org>.  Copyright 2007,
# Tim Skirvin.  Redistribution terms are below.
###############################################################################

=head1 NAME

News::Lock - shared locking functions for News::Archive and friends

=head1 SYNOPSIS

  use News::Lock;
  use @ISA; 
  push @ISA, "News::Lock";

  $object->lock;                # Lock for R/W 
  $object->readlock;            # Lock for read-only
  $object->unlock;              # Unlock

See below for more information.

=head1 DESCRIPTION

News::Lock offers a consistent set of locking functions for use across
various News::Archive objects (and beyond, if necessary).

Modules that use this package must offer the following functions:

  lockfile()    A filename that can be used for locking onto.  Will be
                created if it doesn't exist, and isn't removed; this can
                be the file that you're locking.
  locked()      Is the object locked?  1 for yes, 0 for no.
  readonly()    What kind of locks are we talking about, by default - 
                LOCK_SH (1) or LOCK_EX (0)?  
  reload()      After an unlock (and subsequent write-out), reload the 
                object.  
  debug()       If the object's debug flag is set, then we will print
                various debugging information; otherwise, we won't.

Stubs for all of these functions are offered, but you may want to override 
them.  

=head1 USAGE

Besides the above listed stubs, the following options are offered:

=over 4

=cut

###############################################################################
### main() ####################################################################
###############################################################################

use strict;
use Fcntl qw(:DEFAULT :flock);
use Exporter;

use vars qw( @EXPORT @EXPORT_OK );
@EXPORT    = qw( lock readlock unlock );
@EXPORT_OK = qw( lockfile locked readonly reload debug );

# stubs
sub lockfile { $_[0]->{lockfile} }
sub locked   { $_[0]->{lock} ? 1 : 0 }         
sub readonly { $_[0]->{readonly} }
sub reload   { }
sub debug    { 0 }

=item lock ( OPTHASH )

Get an exclusive, read-write lock on the object (LOCK_EX).  Returns the lock if
successful, 0 otherwise.  Note that there are various warnings and debugging
messages printed if debug is set.

If there is already a readonly lock, then we'll close that one first and open
a new read-write lock.  Sets 'readonly' to 0. 

=cut

sub lock {
  my ($self, %opts) = @_;
  my $lockfile = $self->lockfile;

  ## If we already have a lock, there are two possibilities:
  ##   1.  We've got a write lock; if so, we're done.
  ##   2.  We have a readlock, in which case we'll want to close that and 
  ##       start over in case somebody else needs to write first.  So unlock
  ##       and reload.

  if ($self->locked) { 
    return $self->{lock} unless $self->readonly; 
    $self->unlock('noread' => 1);                       # readlock must die
  }

  ## Actually get the lock.  Note that there are many opportunities for 
  ## warnings here; we probably ought to look for a QUIET variable or similar.

  print "Locking $lockfile (LOCK_EX)\n" if $self->debug;
  unless ( sysopen ( DBLOCK, $lockfile, O_RDWR|O_CREAT ) )  {
    $self->debug ? print "Couldn't create lockfile $lockfile: $!\n"
                 : warn  "Couldn't create lockfile $lockfile: $!\n";
    return 0;
  }
  unless ( flock( DBLOCK, LOCK_EX | LOCK_NB ) ) { 
    print "waiting on lock\n" if $self->debug;
    warn "waiting on lock on $lockfile\n";      # will want to reduce this later
    unless ( flock( DBLOCK, LOCK_EX ) ) {
      $self->debug ? print "Couldn't get lock: $!\n"
                   : warn "Couldn't get lock: $!\n";
      return 0;
    }
  } 
  print "Got read-write lock for $lockfile\n" if $self->debug;

  ## Modify the local object and return.

  $self->{lock} = \*DBLOCK;
  $self->{readonly} = 0;

  return $self->{lock};
}

=item readlock ( OPTHASH )

Get a shared, read-only lock on the object (LOCK_SH).  Returns the lock, either
if it already exists or if we make a new one; returns 0 otherwise.  Note that
there are various warnings and debugging messages printed if debug is set.

Sets 'readonly' to 1 if we make the new lock. 

=cut

sub readlock {
  my ($self, %opts) = @_;

  ## If we already have a lock, there are two possibilities:
  ##   1.  We've got a write lock; if so, then fine, it's a readlock too.  
  ##       We're done.
  ##   2.  We have a readlock, in which case we're done.

  return $self->{lock} if $self->locked;

  ## Actually get the lock.  Note that there are many opportunities for 
  ## warnings here; we probably ought to look for a QUIET variable or similar.

  my $lockfile = $self->lockfile;
  print "Locking $lockfile (LOCK_SH)\n" if $self->debug;
  unless ( sysopen ( DBLOCK, $lockfile, O_RDONLY|O_CREAT ) )  {
    $self->debug ? print "Couldn't create lockfile $lockfile: $!\n"
                 : warn  "Couldn't create lockfile $lockfile: $!\n";
    return 0;
  }
  unless ( flock( DBLOCK, LOCK_SH ) ) {
    print "Couldn't get lock for $lockfile: $!\n" if $self->debug;
    return 0;
  }
  print "Got read-only lock for $lockfile\n" if $self->debug;

  ## Modify the local object and return.

  $self->{lock} = \*DBLOCK;
  $self->{readonly} = 1;

  return $self->{lock};
}

=item unlock ( OPTHASH )

Unlock the object, no matter the type.  Returns 1 if successful, 0 otherwise.

Options that can be offered:

  noread        Unless this is set, we will run readlock() and reload() 
                after unlocking this object.

=cut

sub unlock {
  my ($self, %opts) = @_;

  ## There's not much to do if we're not locked.
  my $lock = $self->{lock} or return 1;

  ## Unlock the lock, no matter the type.
  my $lockfile = $self->lockfile;
  my $readonly = $$self{readonly} ? "readonly" : "read-write";
  print "Releasing $readonly lock on $lockfile\n" if $self->debug;
  CORE::close $lock;
  $self->{lock} = "";

  ## Unless we specifically don't want to, let's reload our object as read-
  ## only, so we can keep on working.
  unless ($opts{'noread'}) { $self->readlock && $self->reload; }

  1;
}

1;

=back

=head1 NOTES

=head1 TODO

Needs to be implemented across the rest of the News::Archive modules; but that's
not really this one's fault.

=head1 REQUIREMENTS

=head1 SEE ALSO

=head1 AUTHOR

Tim Skirvin <tskirvin@killfile.org>

=head1 HOMEPAGE

B<http://www.killfile.org/~tskirvin/software/news-archive/>

=head1 LICENSE

This code may be redistributed under the same terms as Perl itself.

=head1 COPYRIGHT

Copyright 2007, Tim Skirvin.

=cut

###############################################################################
### Version History ###########################################################
###############################################################################
# 0.90          Sun 11 Mar 12:02:48 CST 2007    tskirvin
### Documentation works, but I haven't tested it very much yet.
# 0.01          Wed 07 Mar 14:56:19 CST 2007    tskirvin
### Initial version; documentation isn't finished by any means.
