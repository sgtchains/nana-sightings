$VERSION = "0.10";
package News::Queue::Entry;
our $VERSION = "0.10";

# -*- Perl -*- 		# Wed Apr 28 09:38:34 CDT 2004 
###############################################################################
# Written by Tim Skirvin <tskirvin@killfile.org>.  Copyright 2003-2004,
# Tim Skirvin.  Redistribution terms are below.
###############################################################################

=head1 NAME

News::Queue::Entry - an object for storing specific group information

=head1 SYNOPSIS

  use News::Queue::Entry;

See News::Queue and below for more specific information about related
functions.

=head1 DESCRIPTION

News::Queue::Entry contains the actual queue entries for
News::Queue.  Each entry consists of [...]

=head1 USAGE

News::Queue::Entry is accessed through the following functions:

=cut

###############################################################################
### main() ####################################################################
###############################################################################

use strict;

=head2 Functions

=over 4

=item new ( STRING )

Creates and returns a new News::Queue::Entry object.  C<STRING> is a
scalar containing the group name, timestamp of creation, creator name, and
group description, separated by '::'.  

Only the group name is really required; the rest will be worked on on
their own.  Therefore, just passing in the group name will work fine.

=cut

sub new {
  my ($proto, $string) = @_;
  my ($id, $status, $yesvote, $novote, $ctime, $mtime) = split('::', $string);
  return undef unless $id;
  my $class = ref($proto) || $proto;
  my $self = {
        'id'      => $id       || '',
        'status'  => $status   || 'queue',
	'yesvote' => {}, 
        'novote'  => {},
	'ctime'	  => $ctime    || time,
	'mtime'	  => $mtime    || time,
 	     };
  foreach (split(',', $yesvote || "")) { $$self{yesvote}++ } 
  foreach (split(',', $novote || ""))  { $$self{novote}++  } 
  bless $self, $class;
}

=item id ( )

=item ctime ( )

=item yesvotes ( )

=item novotes ( )

Returns the relevant information.  Note that these cannot be reset through 
these functions.  yesvotes() and novotes() return hash references.

=cut

sub id       { $_[0]->{id} }
sub ctime    { $_[0]->{ctime} }
sub yesvotes { $_[0]->{yesvote} }
sub novotes  { $_[0]->{novote} }

=item status ( [STRING] )

=item mtime ( [TIME] )

Returns the relevant information from the object, as indicated above.  If
an argument is passed to these functions, then the value is set to that
value; otherwise, we just return the existing value.

status() updates mtime() as well.

=cut

sub status  { defined $_[1] ? $_[0]->{status} = $_[1] 
                            : ( $_[0]->{status} || "" && $_[0]->mtime(time) ) };
sub mtime   { defined $_[1] ? $_[0]->{'mtime'} = $_[1] : $_[0]->{'mtime'} || 0 }

=item vote ( USER [, VOTE] )

=cut

sub vote {
  my ($self, $user, $vote) = @_;
  return undef unless $user;

  my $yes = $self->yesvotes;
  my $no  = $self->novotes;
  if (defined $vote) { 
    if ( $vote == 1 ) { 
      return 1 if ($$yes{$user});       # already done
      $$yes{$user} = 1; $$no{$user} = 0; return 1;  $self->mtime(time);
    } elsif ( $vote == 0 ) {
      return 0 unless ($$yes{$user} || $$no{$user});
      $$yes{$user} = 0; $$no{$user} = 0; return 0;  $self->mtime(time);
      return 0;
    } elsif ( $vote == -1 ) {
      return -1 if ($$no{$user});
      $$yes{$user} = 0; $$no{$user} = 1; return -1; $self->mtime(time);
    } else { warn "invalid vote: $vote\n"; return 0; }
  } else { 
    return 1  if ($$yes{$user});
    return -1 if ($$no{$user});
    return 0;
  }
  
  undef;
}

=item arrayref ()

Returns an array reference containing C<time()>, C<creator()>, and
C<desc()> (the same information stored by INN's various newsgroup files).

=cut

sub arrayref { my ($self) = @_; [ $self->status, 
                join(',', keys %{$self->yesvotes}), 
                join(',', keys %{$self->novotes}), 
                $self->ctime, $self->mtime ]; }

=item print ()

Makes a human-readable string containing the information from arrayref().

=cut

sub print    { join("\t", @{shift->arrayref}) }

=item prettyprint ()

=cut

sub prettyprint {
  my $self = shift;
  my @info = @{$self->arrayref};
  my @return;
  push @return, ucfirst lc shift @info;
  push @return, join(", ", split(',', shift @info ));
  push @return, join(", ", split(',', shift @info));
  push @return, scalar localtime(shift @info);
  push @return, scalar localtime(shift @info);
  wantarray ? @return : \@return;
}

sub prettyprint_head {
  ("Message-ID","Status","Yes Votes","No Votes","Created","Last Modified");
}

=item output ()

Returns the string that is needed by new() - ie, a string containing
name() and arrayref(), separated by '::'.  

=cut

sub output   { my $self = shift; join("::", $self->id, @{$self->arrayref}) }

=back

=cut

1;

=head1 REQUIREMENTS

B<News::Queue>

=head1 SEE ALSO

B<News::Queue>

=head1 AUTHOR

Tim Skirvin <tskirvin@killfile.org>

=head1 HOMEPAGE

B<http://www.killfile.org/~tskirvin/software/news-archive/>

=head1 LICENSE

This code may be redistributed under the same terms as Perl itself.

=head1 COPYRIGHT

Copyright 2007, Tim Skirvin.

=cut

###############################################################################
##### Version History #########################################################
###############################################################################
# 0.01          Wed 07 Mar 14:49:47 CST 2007    tskirvin
### Initial version.
